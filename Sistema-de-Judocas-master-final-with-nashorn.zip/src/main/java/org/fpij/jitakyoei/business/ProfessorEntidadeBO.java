package org.fpij.jitakyoei.business;

import java.util.List;

import org.fpij.jitakyoei.model.beans.ProfessorEntidade;

public interface ProfessorEntidadeBO {
	public void createProfessorEntidade(List<ProfessorEntidade> relacionamentos)
	throws Exception;
}
